//Custom JavaScript
$(document).ready(function () {
    $('[data-toggle="popover"]').popover();
});